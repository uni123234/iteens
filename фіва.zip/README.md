# GoiTeens Python Bot

## Introduction

This Python bot is designed to help GoiTeens improve their English language skills through various commands and activities.

## Commands

### /start

Initiate registration and take a level test in English.

### /info

Provide information about the bot and its functions.

### /test

Access English tests to improve your language skills.

### /learn

Learn new words, their correct pronunciation, and watch related videos.

### /myprogress

Check your progress in the English language learning journey.

### /howdoisay

Translate text into English.
